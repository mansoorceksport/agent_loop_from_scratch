from dataclasses import dataclass
from typing import Protocol


@dataclass
class BalanceModel:
    id: str
    date: str
    amount: int

@dataclass
class BalanceNotFoundError:
    message: str

class BalanceRepository(Protocol):
    def balance_by_date(self, date_string: str)-> BalanceModel | BalanceNotFoundError:
        ...